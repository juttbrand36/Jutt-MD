legend profile
